const { expect } = require('chai');
const { ethers } = require('hardhat');
require('@openzeppelin/test-helpers/configure')({
  provider: 'http://localhost:8545',
});

describe('CallStaking', function () {
  let account1;
  let account2;
  let account3;
  let callStaking;

  before(async () => {
    [account1, account2, account3] = await ethers.getSigners();
    const CallStaking = await ethers.getContractFactory('CallStaking');
    callStaking = await CallStaking.deploy();
    await callStaking.deployed();
  });
  it('deposit', async function () {
    await callStaking.deposit({
      value: ethers.utils.parseUnits('100', 'ether').toString(),
    });
    console.log('deposited');
    const blockNumBefore = await ethers.provider.getBlockNumber();
    const blockBefore = await ethers.provider.getBlock(blockNumBefore);
    const timestampBefore = blockBefore.timestamp;
    console.log('timestampBefore', timestampBefore);

    await ethers.provider.send('evm_increaseTime', [
      365 * 24 * 60 * 60 + 10000,
    ]);
    await ethers.provider.send('evm_mine');

    const blockNumAfter = await ethers.provider.getBlockNumber();
    const blockAfter = await ethers.provider.getBlock(blockNumAfter);
    const timestampAfter = blockAfter.timestamp;
    console.log('timestampAfter ', timestampAfter);

    const [invests, rewards] = await callStaking.getStakingData(
      account1.address
    );

    console.log(
      'after a year, reward will be: ',
      invests.toString(),
      rewards.toString()
    );
  });
});
